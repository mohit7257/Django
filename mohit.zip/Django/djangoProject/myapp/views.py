from django.http import HttpResponse, request
from django.middleware.csrf import get_token
from django.shortcuts import render
def home(request):
    return HttpResponse("Hello, World!")

def about(request):
    return HttpResponse("This is the about page.")

def contact(request):
    return HttpResponse("This is the contact page.")

def student(request):
    name = "Aamir"
    return HttpResponse(f"Hello, {name}! This is the student page.")

# this is the marks view function
def marks(request):
    marks = 60  # Example marks value
    if marks >= 80:
        return HttpResponse(f"Your marks are: {marks}. Ecellent work! Keep it up!")
    elif marks >= 60:
        return HttpResponse(f"Your marks are: {marks}. Good job! You can do even better!")
    elif marks >= 40:
        return HttpResponse(f"Your marks are: {marks}. Keep trying!")
    else:
        return HttpResponse(f"Your marks are: {marks}. failed. Don't give up, keep learning and improving!")


# this is the weather view function
def weather(request):
    weather = "sunny"  # Example weather value
    if weather == "sunny":
        return HttpResponse("It's a sunny day! Enjoy the sunshine!")
    elif weather == "rainy":
        return HttpResponse("It's a rainy day! Don't forget your umbrella!")
    elif weather == "cloudy":
        return HttpResponse("It's a cloudy day! You might want to carry a light jacket.")
    else:
        return HttpResponse("I don't know the weather.")


# this is the menuitems view function using for loop to display menu items and their prices with key value pair in dictionary
def menuitems(request):
    items ={
        'pizza' : 'Pizza costs Rs. 600',
        'burger' : 'Burger costs Rs. 200',
        'pasta' : 'Pasta costs Rs. 400',
    }
    output = "<h1>Menu Items</h1>"

    for item, price in items.items():
        output += f"{item}: {price}<br>"

    return HttpResponse(output)

#dynamic url using path converter to display student name

def greet(request, name):
    return HttpResponse(f"Hello, {name}!")

#dynamic url using path converter to display with key value pair in dictionary to display food item and its price


def fooditem(request, item):
    items = {
        'pizza': {'name': 'Pizza', 'price': 600},
        'burger': {'name': 'Burger', 'price': 200},
        'pasta': {'name': 'Pasta', 'price': 400},
    }
    if item in items:
        return HttpResponse(f"{items[item]['name']}: costs Rs. {items[item]['price']}")
    else:
        return HttpResponse(f"Sorry, we don't have {item} on the menu.")


#query parameter using request.GET to display student name and age
def recipe(request):
    food = request.GET.get('food', 'No food item specified')
    if not food:
        return HttpResponse("No food item specified.", status=404)
    return HttpResponse(
        f"Food item: {food}"
)

def restaurant(request):
    food = request.GET.get('food', 'No food item specified')
    city = request.GET.get('city', 'No city specified')
    type = request.GET.get('type', 'No type specified')

    return HttpResponse(
        f"Food item: {food}<br>City: {city}<br>Type: {type}"
    )


def addition(request):
    num1 = request.GET.get('num1')
    num2 = request.GET.get('num2')
    result = int(num1) + int(num2)
    return HttpResponse(f"The sum of {num1} and {num2} is: {result}")

#calculator view function to perform basic arithmetic operations based on query parameters
def calculator(request):
    num1 = request.GET.get('num1')
    num2 = request.GET.get('num2')
    operation = request.GET.get('operation')

    if num1 is None or num2 is None or operation is None:
        return HttpResponse(
            "Please provide num1, num2, and operation (add, subtract, multiply, or divide)."
        )

    
    num1 = float(num1)
    num2 = float(num2)
    

    if operation == 'add':
        result = num1 + num2
    elif operation == 'subtract':
        result = num1 - num2
    elif operation == 'multiply':
        result = num1 * num2
    elif operation == 'divide':
        if num2 == 0:
            return HttpResponse("Cannot divide by zero.")
        result = num1 / num2


    return HttpResponse(f"The result of {operation} on {num1} and {num2} is: {result}")


#regular expression url using re_path to display student name and age



def student_info(request, username):
    return HttpResponse(f"Student Name: {username}, Age: 20")

def student_details(request, date):
    return HttpResponse(f"Student age: {date}", )

def restro_details(request, category, subcategory):
    if not subcategory:
        message = f"Category: {category}, Subcategory is missing."
    else:
        message = f"Category: {category}, Subcategory: {subcategory}"
    return HttpResponse(message)
   


#erorr handling view function to display error message when user enters invalid url

def handler404(request, exception):
    return HttpResponse("<h1 style='color: red;'>Page not found. Please check the URL and try again.</h1>", status=404)


#for home template view function to display home page using template

def home_template(request):
    name = "Aamir"
    return render(request, 'home.html', {'name': name})

#for about template view function to display about page using template

def about_template(request):
    context ={
        "name": "Aamir",
        "age": 20,
        "course": "Django",
        "semster": 7,
        "Marks": 80,
    }
    return render(request, 'about.html', context)

# filter view function to display student name and age using filter in template


def student_template(request):
    context = {
        "name": "Aamir",
        "course": "Django",
        "city": "",
        "students": [
            "Aamir",
            "Ali",
            "Ahmed",
            "Asad",
        ]

    }
    return render(request, 'filter.html', context)

def result(request):
    context = {
        "name": "Aamir",
        "marks": 80,
    }
    return render(request, 'result.html', context)

# for loop view function to display student name and age using for loop in template

def for_loop(request):
    menu = [
        "Pizza",
        "Burger",
        "Pasta",
        "Salad",
    ]

    context = {
    "menu": menu,
    }

    return render(request, 'for_loop.html', context)


#form view function to display student name and age using form in template

def simple_form(request):
    csrf_token=get_token(request) # Get the CSRF token
    if request.method == "POST":
        print(request.POST)
        name = request.POST.get("name")
        return HttpResponse(f"Hello, {name}!")
    return HttpResponse(f"""
                        <form method="POST">
                            <input type="hidden" 
                                    name="csrfmiddlewaretoken"
                                    value="{csrf_token}">

                            <input type="text" name="name">
                            <br>
                            
                            
                            <input type="submit" value="Submit">
                        </form>
                    """)

def stu_form(request):
    if request.method == "POST":
        name = request.POST.get("name")
        age = request.POST.get("age")
        return HttpResponse(f"Hello, {name}! You are {age} years old.")
    return render(request, 'form.html')


def add_student(request):
    if request.method == "POST":
        print(request.POST)
        roll = request.POST.get("roll")
        name = request.POST.get("name")
        course = request.POST.get("course")
        marks = request.POST.get("marks")

        data = {
            "roll" : roll,
            "name" : name,
            "course" : course,
            "marks" : marks,
        }

        return render(request, "form.html", data)
    return render(request, "form.html")



from .forms import InputForm


def form(request):
    if request.method=="POST":
        form = InputForm(request.POST)
        if form.is_valid:
            return HttpResponse("Form Submited Successfully")

    else:
        form= InputForm()

    return render(request, "input_form.html", {"form": form})


# pyhton model 
    