from django.urls import path, re_path
from . import views

urlpatterns = [
    path('', views.home),
    path('about/', views.about),
    path('contact/', views.contact),
    path('student/', views.student),
    path('marks/', views.marks),
    path('weather/', views.weather),
    path('menuitems/', views.menuitems),
    path("greet/<str:name>/", views.greet),
    path("food/<str:item>/", views.fooditem),\
    path("recipe/", views.recipe),
    path("restaurant/", views.restaurant),
    path("addition/", views.addition),
    path("calculator/", views.calculator),
    re_path(r'^student/(?P<username>[a-zA-Z]+)/$', views.student_info),
    re_path(r'^date/(?P<date>\d{4})/$', views.student_details),
    re_path(r'^caffe/(?P<category>[\w]+)/?(?P<subcategory>[\w-]*)/$', views.restro_details),
    path('home-template/', views.home_template),
    path('about-template/', views.about_template),
    path('student-template/', views.student_template),
    path('result/', views.result),
    path('for-loop/', views.for_loop),
    path('form/', views.simple_form),
    path('stu-form/', views.stu_form),
    path('add_student', views.add_student),
    path('input_form/',views.form),


]

handler_404="myproject.exc"