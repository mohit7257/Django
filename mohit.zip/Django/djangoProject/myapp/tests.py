from django.test import TestCase

# Create your tests here.
class HomeTest(TestCase):
    def test_home(self):
        self.assertEqual(1 + 1, 2)


class HomeViewTest(TestCase):
    def test_home_view(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
    def test_home_contains_content(self):
        response = self.client.get('/')
        self.assertContains(response, 'Hello, World!')

    def test_home_template_used(self):
        response = self.client.get('/home-template/')
        self.assertTemplateUsed(response, 'home.html')